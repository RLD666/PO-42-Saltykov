﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atelie
{
    public partial class MenegReg : Form
    {
        public MenegReg()
        {
            InitializeComponent();
        }

        private void regbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                con.Open();
                string add_data = "INSERT INTO [dbo].[Users] Values (@login, @password)";
                SqlCommand cmd = new SqlCommand(add_data, con);


                cmd.Parameters.AddWithValue("@login", login.Text);
                cmd.Parameters.AddWithValue("@password", password.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                login.Text = "";
                password.Text = "";

                MessageBox.Show("Вы успешно зарегистрировали менеджера");
            }
            catch
            {
                MessageBox.Show("Регистрация не удалась. Ошибка#06");
            }
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            admin_panel ap = new admin_panel();
            ap.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MenegReg_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(login, "Введите логин, не менее 5 символов.");
            toolTip2.SetToolTip(password, "Введите пароль, не менее 5 символов.");
        }

        private void MenegReg_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

    }
}
