﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atelie
{
    public partial class Avtor : Form
    {
        public Avtor()
        {
            InitializeComponent();
        }

        private void vhodbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                con.Open();
                string add_data = "SELECT * FROM [dbo].[Users] where login=@login and password=@password";
                SqlCommand cmd = new SqlCommand(add_data, con);

                cmd.Parameters.AddWithValue("@login", avtor_login.Text);
                cmd.Parameters.AddWithValue("@password", avtor_password.Text);
                cmd.ExecuteNonQuery();
                int count = Convert.ToInt32(cmd.ExecuteScalar());

                con.Close();

                if (avtor_login.Text == "admin")
                {
                    if (avtor_password.Text == "admin")
                    {
                        MessageBox.Show("Вы успешно авторизовались, администратор");
                        admin_panel ap = new admin_panel();
                        ap.Show();
                        this.Hide();
                    }
                }
                else if (count > 0)
                {

                    MessageBox.Show("Вы успешно авторизовались");
                    meneger_panel mp = new meneger_panel();
                    mp.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Логин или пароль неверный");
                }
            }
            catch
            {
                MessageBox.Show("Ошибка авторизации. Ошибка #06");
            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ShowBtn_Click(object sender, EventArgs e)
        {
            avtor_password.UseSystemPasswordChar = false;
            ShowBtn.Visible = false;
            HideBtn.Visible = true;
        }

        private void HideBtn_Click(object sender, EventArgs e)
        {
            avtor_password.UseSystemPasswordChar = true;
            ShowBtn.Visible = true;
            HideBtn.Visible = false;
        }

        private void Avtor_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(avtor_login, "Если вы забыли свой логин, то обратитесь к администратору.");
            toolTip2.SetToolTip(avtor_password, "Если вы забыли свой пароль, то обратитесь к администратору.");
        }

        private void Avtor_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
