﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atelie
{
    public partial class Usluga : Form
    {
        SqlDataAdapter sda;
        System.Data.DataTable dt;

        public Usluga()
        {
            InitializeComponent();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            admin_panel ap = new admin_panel();
            ap.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateDataGridView()
        {
            // Получаем данные из базы данных и обновляем источник данных DataGridView
            string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM [dbo].[Usluga]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void vhodbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                con.Open();
                string add_data = "INSERT INTO [dbo].[Usluga] Values (@name_u, @cost)";
                SqlCommand cmd = new SqlCommand(add_data, con);


                cmd.Parameters.AddWithValue("@name_u", name_u.Text);
                cmd.Parameters.AddWithValue("@cost", cost.Text);
                //cmd.Parameters.AddWithValue("@Фотография", textBox1.Text);
                cmd.ExecuteNonQuery();
                // Обновляем DataGridView
                dt.AcceptChanges();
                con.Close();
                name_u.Text = "";
                cost.Text = "";
                //textBox1.Text = "";

                MessageBox.Show("Вы успешно создали услугу");
                UpdateDataGridView();
            }
            catch
            {
                MessageBox.Show("Регистрация не удалась. Ошибка#06");
            }
        }

        private void ObnovBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
            sda = new SqlDataAdapter(@"SELECT ID_usluga, name_u, cost FROM Usluga", conn);

            dt = new System.Data.DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 60;

                dataGridView1.Columns[0].HeaderText = "Код услуги";
                dataGridView1.Columns[1].HeaderText = "Название услуги";
                dataGridView1.Columns[2].HeaderText = "Стоимость";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 90;
                dataGridView1.Columns[1].Width = 260;
                dataGridView1.Columns[2].Width = 90;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string conString = @"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = Atelie; Integrated Security=True; Pooling=False";
            SqlConnection conn = new SqlConnection(conString);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Usluga", conn);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            System.Data.DataTable dt = (System.Data.DataTable)dataGridView1.DataSource;
            sda.Update(dt);

            if (dataGridView1.SelectedRows.Count > 0)
            {
                    // Получаем выбранную строку
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Получаем идентификатор строки
                    int id = Convert.ToInt32(selectedRow.Cells[0].Value);

                    // Создаем команду SQL для обновления данных
                    string updateQuery = "UPDATE Usluga SET name_u = @name_u, cost = @cost WHERE ID_usluga = @ID_usluga";
                    SqlCommand command = new SqlCommand(updateQuery, conn);
                    command.Parameters.AddWithValue("@name_u", textBox1.Text);
                    command.Parameters.AddWithValue("@cost", numericUpDown1.Text);
                    command.Parameters.AddWithValue("@ID_usluga", id);

                    // Выполняем команду SQL
                    command.ExecuteNonQuery();

                    // Обновляем DataGridView
                    dt.AcceptChanges();

                    // Очищаем текстовые поля
                    textBox1.Text = "";
                    numericUpDown1.Text = "100";
                    UpdateDataGridView();
                }
            }
            catch
            {
                MessageBox.Show("Что-то пошло не так");
            }
        }

        private void Usluga_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT ID_usluga, name_u, cost FROM Usluga", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 60;

                dataGridView1.Columns[0].HeaderText = "Код услуги";
                dataGridView1.Columns[1].HeaderText = "Название услуги";
                dataGridView1.Columns[2].HeaderText = "Стоимость";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 90;
                dataGridView1.Columns[1].Width = 260;
                dataGridView1.Columns[2].Width = 90;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }

            toolTip1.SetToolTip(name_u, "Введите название услуги, к примеру: 'Рубашка'.");
            toolTip1.SetToolTip(textBox1, "Введите название услуги, к примеру: 'Рубашка'.");
        }

        private void Usluga_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
