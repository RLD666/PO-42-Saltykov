﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Atelie
{
    public class Zacaz
    {
        private int id_zacaz;
    }
}