﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atelie
{
    public partial class Master : Form
    {
        SqlDataAdapter sda;
        System.Data.DataTable dt;

        public Master()
        {
            InitializeComponent();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            admin_panel ap = new admin_panel();
            ap.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateDataGridView()
        {
            // Получаем данные из базы данных и обновляем источник данных DataGridView
            string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM [dbo].[Master]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void vhodbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                con.Open();
                string add_data = "INSERT INTO [dbo].[Master] Values (@name_m, @id_usluga)";
                SqlCommand cmd = new SqlCommand(add_data, con);


                cmd.Parameters.AddWithValue("@name_m", name_m.Text);
                cmd.Parameters.AddWithValue("@id_usluga", id_usluga.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                name_m.Text = "";
                id_usluga.Text = "";

                MessageBox.Show("Вы успешно зарегистрировали мастера");
                // Обновляем DataGridView
                UpdateDataGridView();
            }
            catch
            {
                MessageBox.Show("Регистрация не удалась. Ошибка#06");
            }
        }

        private void ObnovBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
            sda = new SqlDataAdapter(@"SELECT ID_master, name_m, id_usluga FROM Master", conn);

            dt = new System.Data.DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 60;

                dataGridView1.Columns[0].HeaderText = "Код мастера";
                dataGridView1.Columns[1].HeaderText = "ФИО мастера";
                dataGridView1.Columns[2].HeaderText = "Код услуги";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[2].Width = 100;
                dataGridView1.Columns[1].Width = 410;
                dataGridView1.Columns[0].Width = 100;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string conString = @"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = Atelie; Integrated Security=True; Pooling=False";
            SqlConnection conn = new SqlConnection(conString);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Master", conn);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            System.Data.DataTable dt = (System.Data.DataTable)dataGridView1.DataSource;
            sda.Update(dt);

                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Получаем выбранную строку
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Получаем идентификатор строки
                    int id = Convert.ToInt32(selectedRow.Cells[0].Value);

                    // Создаем команду SQL для обновления данных
                    string updateQuery = "UPDATE Master SET name_m = @name_m, id_usluga = @id_usluga WHERE ID_master = @ID_master";
                    SqlCommand command = new SqlCommand(updateQuery, conn);
                    command.Parameters.AddWithValue("@name_m", textBox1.Text);
                    command.Parameters.AddWithValue("@id_usluga", textBox2.Text);
                    command.Parameters.AddWithValue("@ID_master", id);

                    // Выполняем команду SQL
                    command.ExecuteNonQuery();

                    // Обновляем DataGridView
                    dt.AcceptChanges();

                    // Очищаем текстовые поля
                    textBox1.Text = "";
                    textBox2.Text = "";
                    // Обновляем DataGridView
                    UpdateDataGridView();
                }

            }
            catch
            {
                MessageBox.Show("Сохранение не удалось. Ошибка#05");
            }
        }

        private void Master_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT ID_master, name_m, id_usluga FROM Master", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 60;

                dataGridView1.Columns[0].HeaderText = "Код мастера";
                dataGridView1.Columns[1].HeaderText = "ФИО мастера";
                dataGridView1.Columns[2].HeaderText = "Код услуги";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[2].Width = 100;
                dataGridView1.Columns[1].Width = 410;
                dataGridView1.Columns[0].Width = 100;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }

            toolTip1.SetToolTip(name_m, "Если у человека нет отчества, то впишите только фамилию и имя.");
            toolTip1.SetToolTip(textBox1, "Если у человека нет отчества, то впишите только фамилию и имя.");
            toolTip2.SetToolTip(id_usluga, "Введите код услуги, который вы узнали заранее.");
            toolTip2.SetToolTip(textBox2, "Введите код услуги, который вы узнали заранее.");
        }

        private void Master_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
