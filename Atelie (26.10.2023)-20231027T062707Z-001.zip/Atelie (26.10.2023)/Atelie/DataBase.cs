﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Atelie
{
    class DataBase
    {
        const string connectionString = @"Data Source=WIN-20U0C7VPB4C; Initial Catalog = Atelie; Integrated Security=True; Pooling=False";

        public static void Addzacaz(string id_usluga, string id_client, string id_master, DateTime date_start, DateTime date_end, int sum, string photo)
        {
            string addRequest = $"INSERT INTO dbo.Zacaz VALUES ('{id_usluga}','{id_client}','{id_master}','{date_start.Date}', '{date_end.Date}','{sum}','{photo}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }
    }
}
