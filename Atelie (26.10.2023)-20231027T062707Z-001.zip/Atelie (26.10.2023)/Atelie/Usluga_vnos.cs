﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Atelie
{
    class Usluga_vnos
    {
        const string connectionString = "Data Source=(localdb)\\MSSQLLocalDB; Database = Atelie; Integrated Security = True";
        public static void Addusluga(string name_u, string cost, string photo)
        {
            string addRequest = $"INSERT INTO dbo.Zacaz VALUES ('{name_u}','{cost}','{photo}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }
    }
}
