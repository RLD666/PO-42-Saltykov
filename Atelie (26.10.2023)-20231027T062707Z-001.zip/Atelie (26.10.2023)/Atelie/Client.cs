﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Atelie
{
    public partial class Client : Form
    {
        SqlDataAdapter sda;
        System.Data.DataTable dt;


        public Client()
        {
            InitializeComponent();
        }

        private void UpdateDataGridView()
        {
            // Получаем данные из базы данных и обновляем источник данных DataGridView
            string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM [dbo].[Client]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void vhodbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                con.Open();
                string add_data = "INSERT INTO [dbo].[Client] Values (@name_c, @phone)";
                SqlCommand cmd = new SqlCommand(add_data, con);


                cmd.Parameters.AddWithValue("@name_c", name_c.Text);
                cmd.Parameters.AddWithValue("@phone", phone.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                name_c.Text = "";
                phone.Text = "";

                MessageBox.Show("Вы успешно зарегистрировали клиента");
                UpdateDataGridView();
            }
            catch
            {
                MessageBox.Show("Регистрация не удалась. Ошибка#06");
            }
        }

        private void ObnovBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
            sda = new SqlDataAdapter(@"SELECT id_client, name_c, phone FROM Client", conn);

            dt = new System.Data.DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderText = "Код клиента";
                dataGridView1.Columns[1].HeaderText = "ФИО клиента";
                dataGridView1.Columns[2].HeaderText = "Номер телефона";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[2].Width = 150;
                dataGridView1.Columns[1].Width = 400;
                dataGridView1.Columns[0].Width = 80;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string conString = @"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = Atelie; Integrated Security=True; Pooling=False";
                SqlConnection conn = new SqlConnection(conString);
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from Client", conn);
                SqlCommandBuilder scb = new SqlCommandBuilder(sda);
                System.Data.DataTable dt = (System.Data.DataTable)dataGridView1.DataSource;
                sda.Update(dt);

                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Получаем выбранную строку
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Получаем идентификатор строки
                    int id = Convert.ToInt32(selectedRow.Cells[0].Value);

                    // Создаем команду SQL для обновления данных
                    string updateQuery = "UPDATE Client SET name_c = @name_c, phone = @phone WHERE id_client = @id_client";
                    SqlCommand command = new SqlCommand(updateQuery, conn);
                    command.Parameters.AddWithValue("@name_c", textBox1.Text);
                    command.Parameters.AddWithValue("@phone", textBox2.Text);
                    command.Parameters.AddWithValue("@id_client", id);

                    // Выполняем команду SQL
                    command.ExecuteNonQuery();

                    // Обновляем DataGridView
                    dt.AcceptChanges();

                    // Очищаем текстовые поля
                    textBox1.Text = "";
                    textBox2.Text = "";
                    UpdateDataGridView();
                }
            }
            catch
            {
                MessageBox.Show("Сохранение не удалось. Ошибка#05");
            }
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            meneger_panel mp = new meneger_panel();
            mp.Show();
            this.Hide();
        }

        private void Client_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT id_client, name_c, phone FROM Client", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderText = "Код клиента";
                dataGridView1.Columns[1].HeaderText = "ФИО клиента";
                dataGridView1.Columns[2].HeaderText = "Номер телефона";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[2].Width = 150;
                dataGridView1.Columns[1].Width = 400;
                dataGridView1.Columns[0].Width = 80;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }

            toolTip1.SetToolTip(name_c, "Если у человека нет отчества, то впишите только фамилию и имя.");
            toolTip1.SetToolTip(textBox1, "Если у человека нет отчества, то впишите только фамилию и имя.");
            toolTip2.SetToolTip(phone, "Пример: '89005551515'.");
            toolTip2.SetToolTip(textBox2, "Пример: '89005551515'.");

        }

    }
}
