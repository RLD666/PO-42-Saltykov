﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Word;
using System.Globalization;
using System.Reflection;
using Xceed.Words.NET;
using System.Data.OleDb;
using Xceed.Document.NET;

namespace Atelie
{
    public partial class meneger_panel : Form
    {
        SqlDataAdapter sda;
        System.Data.DataTable dt;
        string urlImg = "";

        public meneger_panel()
        {
            InitializeComponent();
        }

        private void UpdateDataGridView()
        {
            // Получаем данные из базы данных и обновляем источник данных DataGridView
            string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM [dbo].[Zacaz]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void meneger_panel_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_usluga, name_u, cost FROM Usluga", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                listBox1.DataSource = dt;
                listBox1.DisplayMember = "name_u";
                listBox1.ValueMember = "id_usluga";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Первый листбокс. Ошибка#04-1");
            }
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_master, name_m, id_usluga FROM Master", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                listBox3.DataSource = dt;
                listBox3.DisplayMember = "name_m";
                listBox3.ValueMember = "id_master";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Второй листбокс. Ошибка#04-2");
            }
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_client, name_c, phone FROM Client", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                listBox2.DataSource = dt;
                listBox2.DisplayMember = "name_c";
                listBox2.ValueMember = "id_client";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Третий листбокс. Ошибка#04-3");
            }

            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT id_zacaz, id_usluga, id_client, id_master, date_start, date_end, sum, photo FROM Zacaz", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 30;

                ///<summary>
                ///Переименование названий столбцов в dataGridView
                ///<return>Установка ширины столбцов</return>
                ///</summary>

                dataGridView1.Columns[0].HeaderText = "Код заказа";
                dataGridView1.Columns[1].HeaderText = "Код услуги";
                dataGridView1.Columns[2].HeaderText = "Код клиента";
                dataGridView1.Columns[3].HeaderText = "Код мастера";
                dataGridView1.Columns[4].HeaderText = "Дата принятия заказа";
                dataGridView1.Columns[5].HeaderText = "Дата готовности заказа";
                dataGridView1.Columns[6].HeaderText = "Сумма";
                dataGridView1.Columns[7].HeaderText = "Фото";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 80;
                dataGridView1.Columns[1].Width = 80;
                dataGridView1.Columns[2].Width = 80;
                dataGridView1.Columns[3].Width = 80;
                dataGridView1.Columns[4].Width = 180;
                dataGridView1.Columns[5].Width = 180;
                dataGridView1.Columns[6].Width = 70;
                dataGridView1.Columns[7].Width = 550;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_usluga = (int)listBox1.SelectedValue;
        }
        void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_client = (int)listBox2.SelectedValue;
        }
        void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_master = (int)listBox3.SelectedValue;
        }

        private void создатьКлиентаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client client = new Client();
            client.Show();
            this.Hide();
        }

        private void chekbtn_Click(object sender, EventArgs e)
        {
            try
            {
                object oMissing = Missing.Value;
                Object oEndOfDoc = "\\endofdoc";
                Microsoft.Office.Interop.Word._Application appw = new Microsoft.Office.Interop.Word.Application();
                Microsoft.Office.Interop.Word._Document dw;
                appw.Visible = true;
                dw = appw.Documents.Add(typeof(Program).Assembly.Location + "/../../../" + "Chek.docx", Visible: true);
                dw.Bookmarks["ID_zacaz"].Range.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                dw.Bookmarks["data_start"].Range.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                dw.Bookmarks["data_end"].Range.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                dw.Bookmarks["sum"].Range.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                string b = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                pictureBox3.ImageLocation = Path.Combine(Environment.CurrentDirectory, b);
                dw.Bookmarks["photo"].Range.InlineShapes.AddPicture(Path.Combine(Environment.CurrentDirectory, b));


                SqlConnection conn = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Trusted_Connection=true");
                conn.Open();
                SqlCommand Comm = conn.CreateCommand();
                Comm.CommandText = "Select name_m From Master where (id_master = " + dataGridView1.CurrentRow.Cells[3].Value.ToString() + ")";
                dw.Bookmarks["name_m"].Range.Text = Comm.ExecuteScalar().ToString();
                SqlCommand Commn = conn.CreateCommand();
                Commn.CommandText = "Select name_c From Client where (id_client = " + dataGridView1.CurrentRow.Cells[2].Value.ToString() + ")";
                dw.Bookmarks["name_c"].Range.Text = Commn.ExecuteScalar().ToString();
                SqlCommand Commp = conn.CreateCommand();
                Commp.CommandText = "Select phone From Client where (id_client = " + dataGridView1.CurrentRow.Cells[2].Value.ToString() + ")";
                dw.Bookmarks["phone"].Range.Text = Commp.ExecuteScalar().ToString();
                SqlCommand Commu = conn.CreateCommand();
                Commu.CommandText = "Select name_u From Usluga where (id_usluga = " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + ")";
                dw.Bookmarks["name_u"].Range.Text = Commu.ExecuteScalar().ToString();


            }
            catch
            {
                MessageBox.Show("Некорректные данные. Ошибка#02");
            }
        }

        private void администраторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Avtor avtor = new Avtor();
            avtor.Show();
            this.Hide();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Avtor avtor = new Avtor();
            avtor.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ObnovBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT id_zacaz, id_usluga, id_client, id_master, date_start, date_end, sum, photo FROM Zacaz", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                //dataGridView1.RowTemplate.Height = 30;

                ///<summary>
                ///Переименование названий столбцов в dataGridView
                ///<return>Установка ширины столбцов</return>
                ///</summary>

                dataGridView1.Columns[0].HeaderText = "Код заказа";
                dataGridView1.Columns[1].HeaderText = "Код услуги";
                dataGridView1.Columns[2].HeaderText = "Код клиента";
                dataGridView1.Columns[3].HeaderText = "Код мастера";
                dataGridView1.Columns[4].HeaderText = "Дата принятия заказа";
                dataGridView1.Columns[5].HeaderText = "Дата готовности заказа";
                dataGridView1.Columns[6].HeaderText = "Сумма";
                dataGridView1.Columns[7].HeaderText = "Фото";

                this.dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 80;
                dataGridView1.Columns[1].Width = 80;
                dataGridView1.Columns[2].Width = 80;
                dataGridView1.Columns[3].Width = 80;
                dataGridView1.Columns[4].Width = 180;
                dataGridView1.Columns[5].Width = 180;
                dataGridView1.Columns[6].Width = 70;
                dataGridView1.Columns[7].Width = 550;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        private void VnosBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //DataBase.Addzacaz(listBox2.Text, listBox3.Text, listBox1.Text, Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text), int.Parse(numericUpDown2.Text), urlImg);
                DataBase.Addzacaz(listBox1.SelectedValue.ToString(), listBox2.SelectedValue.ToString(), listBox3.SelectedValue.ToString(), Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text), int.Parse(numericUpDown2.Text), urlImg);
                MessageBox.Show("Данные были успешно добавлены.");
                UpdateDataGridView();
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные. Ошибка#02");
            }
        }
        //private void VnosBtn_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        DateTime dateStart;
        //        DateTime dateEnd;
        //        if (DateTime.TryParseExact(dateTimePicker1.Text, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateStart) &&
        //            DateTime.TryParseExact(dateTimePicker2.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateEnd))
        //        {
        //            DataBase.Addzacaz(listBox1.SelectedValue.ToString(), listBox2.SelectedValue.ToString(), listBox3.SelectedValue.ToString(), dateStart, dateEnd, int.Parse(numericUpDown2.Text), urlImg);
        //            MessageBox.Show("Данные были успешно добавлены.");
        //        }
        //        else
        //        {
        //            MessageBox.Show("Некорректный формат даты.");
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Некорректные данные.");
        //    }
        //}

        private void PhotoBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = ofd.FileName;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Title = "Выбрать изображение";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.BackgroundImage = System.Drawing.Image.FromFile(openFile.FileName);
                urlImg = "admin\\" + Path.GetFileName(openFile.FileName);
                //string imgPath = Path.Combine(Environment.CurrentDirectory, urlImg);
                //File.Copy(openFile.FileName, imgPath);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string b = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            pictureBox3.ImageLocation = b;
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox ab = new AboutBox();
            ab.Show();
            this.Hide();
        }

        private void справкаToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, @"Spravka\Курсовая.chm");
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                // Получение выбранной даты из DateTimePicker
                DateTime selectedDate = dateTimePicker3.Value;

                // Фильтрация данных в DataGridView
                DataView dataView = ((System.Data.DataTable)dataGridView1.DataSource).DefaultView;
                dataView.RowFilter = string.Format("date_start = '{0}'", selectedDate.ToString("dd-MM-yyyy HH:mm:ss"));
            }
            catch 
            {
                MessageBox.Show("Фильтрация по дате не была осуществлена. Ошибка#03");
            }

        }

        private void meneger_panel_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}