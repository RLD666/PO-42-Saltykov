﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Atelie
{
    public partial class admin_panel : Form
    {
        SqlDataAdapter sda;
        System.Data.DataTable dt;
        string urlImg = "";

        public admin_panel()
        {
            InitializeComponent();
        }

        private void UpdateDataGridView()
        {
            // Получаем данные из базы данных и обновляем источник данных DataGridView
            string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM [dbo].[Zacaz]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void admin_panel_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_usluga, name_u, cost FROM Usluga", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                UslugaBox.DataSource = dt;
                UslugaBox.DisplayMember = "name_u";
                UslugaBox.ValueMember = "id_usluga";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Первый листбокс. Ошибка#04-1");
            }
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_master, name_m, id_usluga FROM Master", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                MasterBox.DataSource = dt;
                MasterBox.DisplayMember = "name_m";
                MasterBox.ValueMember = "id_master";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Второй листбокс. Ошибка#04-2");
            }
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                SqlCommand cmd = new SqlCommand(@"SELECT id_client, name_c, phone FROM Client", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                dt = new System.Data.DataTable();
                da.Fill(dt);
                ClientBox.DataSource = dt;
                ClientBox.DisplayMember = "name_c";
                ClientBox.ValueMember = "id_client";
            }
            catch
            {
                MessageBox.Show("Возможны ошибки. Третий листбокс. Ошибка#04-3");
            }

            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
                sda = new SqlDataAdapter(@"SELECT id_zacaz, id_usluga, id_client, id_master, date_start, date_end, sum, photo FROM Zacaz", conn);

                dt = new System.Data.DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

                // dataGridView1.RowTemplate.Height = 0; 

                dataGridView1.Columns[0].HeaderText = "Код заказа";
                dataGridView1.Columns[1].HeaderText = "Код услуги";
                dataGridView1.Columns[2].HeaderText = "Код клиента";
                dataGridView1.Columns[3].HeaderText = "Код мастера";
                dataGridView1.Columns[4].HeaderText = "Дата принятия заказа";
                dataGridView1.Columns[5].HeaderText = "Дата готовности заказа";
                dataGridView1.Columns[6].HeaderText = "Сумма";
                dataGridView1.Columns[7].HeaderText = "Фото";

                this.dataGridView1.DefaultCellStyle.Font = new Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 100;
                dataGridView1.Columns[1].Width = 100;
                dataGridView1.Columns[2].Width = 100;
                dataGridView1.Columns[3].Width = 100;
                dataGridView1.Columns[4].Width = 180;
                dataGridView1.Columns[5].Width = 180;
                dataGridView1.Columns[6].Width = 100;
                dataGridView1.Columns[7].Width = 550;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }
        void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_usluga = (int)UslugaBox.SelectedValue;
        }
        void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_master = (int)MasterBox.SelectedValue;
        }
        void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            // получаем id выделенного объекта
            int id_client = (int)ClientBox.SelectedValue;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Database=Atelie;Trusted_Connection=true");
            conn.Open();
            SqlCommand Comm = conn.CreateCommand();
            string b = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            pictureBox3.ImageLocation = b;
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Avtor avtor = new Avtor();
            avtor.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void создатьМенеджераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenegReg mr = new MenegReg();
            mr.Show();
            this.Hide();
        }

        private void создатИзделиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Usluga u = new Usluga();
            u.Show();
            this.Hide();
        }

        private void внестиДанныеМастераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Master m = new Master();
            m.Show();
            this.Hide();
        }

        private void ObnovBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Server = (localdb)\MSSQLLocalDB; Database = Atelie; Integrated Security = True");
            sda = new SqlDataAdapter(@"SELECT id_zacaz, id_usluga, id_client, id_master, date_start, date_end, sum, photo FROM Zacaz", conn);

            dt = new System.Data.DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
   
               // dataGridView1.RowTemplate.Height = 0; 

                dataGridView1.Columns[0].HeaderText = "Код заказа";
                dataGridView1.Columns[1].HeaderText = "Код услуги";
                dataGridView1.Columns[2].HeaderText = "Код клиента";
                dataGridView1.Columns[3].HeaderText = "Код мастера";
                dataGridView1.Columns[4].HeaderText = "Дата принятия заказа";
                dataGridView1.Columns[5].HeaderText = "Дата готовности заказа";
                dataGridView1.Columns[6].HeaderText = "Сумма";
                dataGridView1.Columns[7].HeaderText = "Фото";

                this.dataGridView1.DefaultCellStyle.Font = new Font("Times New Roman", 14);

                dataGridView1.Columns[0].Width = 100;
                dataGridView1.Columns[1].Width = 100;
                dataGridView1.Columns[2].Width = 100;
                dataGridView1.Columns[3].Width = 100;
                dataGridView1.Columns[4].Width = 180;
                dataGridView1.Columns[5].Width = 180;
                dataGridView1.Columns[6].Width = 100;
                dataGridView1.Columns[7].Width = 550;
            }
            catch
            {
                MessageBox.Show("Соединение с базой данных не установлено. Ошибка#01");
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string conString = @"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = Atelie; Integrated Security=True; Pooling=False";
            SqlConnection conn = new SqlConnection(conString);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Zacaz", conn);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            System.Data.DataTable dt = (System.Data.DataTable)dataGridView1.DataSource;
            sda.Update(dt);

                if (dataGridView1.SelectedRows.Count > 0)
                {                    
                    // Получаем выбранную строку
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Получаем идентификатор строки
                    int id = Convert.ToInt32(selectedRow.Cells[0].Value);

                    // Создаем команду SQL для обновления данных
                    string dateStart = dateTimePicker1.Value.ToString("dd-MM-yyyy HH:mm:ss");
                    string dateEnd = dateTimePicker2.Value.ToString("dd-MM-yyyy HH:mm:ss");
                    string updateQuery = "UPDATE Zacaz SET id_usluga = @id_usluga, id_master = @id_master, id_client = @id_client, date_start = @date_start, date_end = @date_end, sum = @sum, photo = @photo WHERE id_zacaz = @id_zacaz";
                    SqlCommand command = new SqlCommand(updateQuery, conn);
                    command.Parameters.AddWithValue("@id_usluga", UslugaBox.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@id_master", MasterBox.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@id_client", ClientBox.SelectedValue.ToString());
                    command.Parameters.AddWithValue("@date_start", DateTime.ParseExact(dateStart, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                    command.Parameters.AddWithValue("@date_end", DateTime.ParseExact(dateEnd, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                    command.Parameters.AddWithValue("@sum", numericUpDown1.Text);
                    command.Parameters.AddWithValue("@photo", urlImg);
                    command.Parameters.AddWithValue("@id_zacaz", id);

                    // Выполняем команду SQL
                    command.ExecuteNonQuery();

                    // Обновляем DataGridView
                    dt.AcceptChanges();

                    // Очищаем текстовые поля
                    numericUpDown1.Text = "0";
                    urlImg = "";
                    UpdateDataGridView();
                }
            }
            catch
            {
                MessageBox.Show("Сохранение не удалось. Ошибка#05");
            }
        }

        private void PhotoBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox4.Text = ofd.FileName;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Title = "Выбрать изображение";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.BackgroundImage = Image.FromFile(openFile.FileName);
                urlImg = "img\\" + Path.GetFileName(openFile.FileName);
                string imgPath = Path.Combine(Environment.CurrentDirectory, urlImg);
                File.Copy(openFile.FileName, imgPath);
            }
        }

        private void admin_panel_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
